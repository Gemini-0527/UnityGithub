﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Game : MonoBehaviour
{   

    public enum GAME_STATUS
    {
        Ready,
        InGame,
        GameOver
    }

    private GAME_STATUS status;

    private GAME_STATUS Status
    {
        get { return status; }
        set
        {
            this.status = value;
            this.UpdateUI();
        }
    }

    public GameObject panelReady;
    public GameObject panelGame;
    public GameObject panelOver;

    public Player player;

    public PipelineManager pipelineManager;

    public int score;
    public Text uiScore;
    public Text uiScore2;

    public int Score
    {
        get { return score; }
        set
        {
            this.score = value;
            this.uiScore.text = this.score.ToString();
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        Application.targetFrameRate = 60;
        ReadyGame();

        this.player.OnDeath += Player_OnDeath;

        this.player.OnScore = OnPlayerScore;
    }

    void OnPlayerScore(int score)
    {
        this.Score += score;
    }

    private void Player_OnDeath()
    {
        this.Status = GAME_STATUS.GameOver;

        this.pipelineManager.Stop();

        Time.timeScale = 0;

        uiScore2.text = uiScore.text;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ReadyGame()
    {
        this.panelReady.SetActive(true);
        Debug.Log("ReadyGame");
    }

    public void StartGame()
    {
        
        this.Status = GAME_STATUS.InGame;
        Debug.LogFormat("StartGame:{0}", this.status);

        pipelineManager.StartRun();

        player.Fly();

    }

    public void Restart()
    {
        uiScore.text = "0";
        score = 0;
        this.Status = GAME_STATUS.Ready;
        pipelineManager.Init();
        this.player.Init();
        Debug.Log("RestartGame");

        Time.timeScale = 1;

    }

    public void UpdateUI()
    {
        this.panelReady.SetActive(this.status == GAME_STATUS.Ready);
        this.panelGame.SetActive(this.status == GAME_STATUS.InGame);
        this.panelOver.SetActive(this.status == GAME_STATUS.GameOver);

    }
}
