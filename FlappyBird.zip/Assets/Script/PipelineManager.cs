﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PipelineManager : MonoBehaviour
{
    public GameObject template;

    public float speed;

    List<Pipeline> pipelines = new List<Pipeline>();

    // Start is called before the first frame update
    void Start()
    {
    
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    Coroutine coroutine = null;

    public void Init()
    {
        for (int i = 0; i < pipelines.Count; i++)
        {
            Destroy(pipelines[i].gameObject);
        }
        pipelines.Clear();
    }

    public void StartRun()
    {
        coroutine = StartCoroutine(GeneratePipelines());
    }

    public void Stop()
    {
       
        for (int i = 0; i < pipelines.Count; i++)
        {
            pipelines[i].enabled = false;
        }
        StopCoroutine(coroutine);
    }

    IEnumerator GeneratePipelines()
    {
        for(int i=0; i < 3;i++)
        {
            if (pipelines.Count < 3)
            {
                CreatePipeLine();
            }
            else
            {
                pipelines[i].enabled = true;
                pipelines[i].Init();
            }

            yield return new WaitForSeconds(speed);
        }
    }

    void CreatePipeLine()
    {
        if (pipelines.Count < 3)
        {
            GameObject obj = Instantiate(template, this.transform);
            Pipeline p = obj.GetComponent<Pipeline>();
            pipelines.Add(p);
        }
    }
}
